# Estado de GitHub

No fue posible empujar esta versión directamente a GitHub desde este entorno porque no hay un repositorio git local enlazado ni credenciales/autorización configuradas para hacer `push`.

La versión `v1.4` ya quedó preparada localmente y empaquetada para subir al repositorio cuando se disponga del remoto/autenticación.
