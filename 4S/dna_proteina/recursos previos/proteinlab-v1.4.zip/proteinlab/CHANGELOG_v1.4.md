# ProteinLab v1.4

## Cambios principales

- Se corrigió la restauración de la vista base de CA2.
- Se añadieron controles directos para:
  - Vista base CA2
  - Centro activo Zn²⁺ + coordinantes
  - Solo Zn²⁺
  - Coordinación Zn–His
  - Enfocar His94
  - Ligando orgánico real: acetazolamida (AZM) usando PDB 3HS4
  - Mostrar/ocultar proteína
  - Mostrar/ocultar aguas
  - Restaurar vista
- Se actualizó el panel de evidencia para distinguir mejor entre cofactor y ligando orgánico.
- Se añadió una nota pedagógica aclarando que hélices alfa y láminas beta no son ligandos.
- Se añadió un modo con CA II + acetazolamida para visualizar un ligando orgánico real con anillos y heteroátomos.

## Estructuras usadas

- 1CA2: CA II humana con Zn²⁺
- 3HS4: CA II humana en complejo con acetazolamida (AZM)

## Observación

La versión HTML depende de que Mol* y los datos PDB puedan cargarse desde internet.
Si eso falla, el prototipo puede caer al modo de respaldo conceptual.
